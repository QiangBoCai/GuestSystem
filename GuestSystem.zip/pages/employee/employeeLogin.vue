<template>
	<view>
		员工使用访客系统首次登录会校验手机号，未入库的给予提示，禁止登录员工入口；
		已入库的员工，校验通过或自动绑定手机号，微信id等信息，下次可直接登录。
		<u-button @click="exployeeLogin">登录</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			exployeeLogin(){
				uni.navigateTo({
					url:"/pages/employee/employee"
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
