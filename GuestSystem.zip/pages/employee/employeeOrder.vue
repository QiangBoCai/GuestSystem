<template>
	<view>
		授权申请：
		员工可以提交访客的基本信息，包含访客姓名，手机，证据类型，证据号码，访客单位，访客事由，访客日期，结束日期，其他信息等。
		生成授权二维码，可微信分享给好友。
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
