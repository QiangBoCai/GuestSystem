<template>
	<view>
		<view @click="onEmployeeOrder">授权申请</view>
		<view @click="onEmployeeRecord">授权记录</view>
		<view @click="onEmployeeCenter">个人中心</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onEmployeeOrder(){
				uni.navigateTo({
					url:"../employee/employeeOrder"
				})
			},
			onEmployeeRecord(){
				uni.navigateTo({
					url:"../employee/employeeRecord"
				})
			},
			onEmployeeCenter(){
				uni.navigateTo({
					url:"../employee/employeeCenter"
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
