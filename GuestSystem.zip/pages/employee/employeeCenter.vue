<template>
	<view>
		个人中心：
		包含了员工的登录信息，可以在此进行账号信息管理，退出登录等操作。
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
