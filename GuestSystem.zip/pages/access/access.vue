<template>
	<view>
		门禁首页:
		门禁页主要包含人脸识别扫描及核验提示；协助门禁人员核验访客信息；
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
