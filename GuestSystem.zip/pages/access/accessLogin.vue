<template>
	<view>
		门禁人员信息（姓名，手机号）会提前录入；密码下发给门禁手机；
		门禁人员首次登录会校验，校验通过后下次直接进入门禁首页；
		<u-button @click="onAccessLogin">登录</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onAccessLogin(){
				uni.navigateTo({
					url:"../access/access"
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
