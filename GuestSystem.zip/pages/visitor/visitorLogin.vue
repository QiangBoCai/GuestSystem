<template>
	<view>
		我是访客> 手机验证登录绑定
		首次 记录访客手机号以及头像信息绑定 微信id,下次微信登录不用验证；直接登录.
		<u-button @click="onBind">绑定</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onBind(){
				uni.navigateTo({
					url:"../visitor/visitor"
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
