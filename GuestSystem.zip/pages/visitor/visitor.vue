<template>
	<view>
			<view @click="onVisitorOrder">访客预约</view>
			<view @click="onVisitorRecord">我的记录</view>
			<view @click="onVisitorCenter">个人中心</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onVisitorOrder(){
				uni.navigateTo({
					url:"../visitor/visitorOrder"
				})
			},
			onVisitorRecord(){
				uni.navigateTo({
					url:"../visitor/visitorRecord"
				})
			},
			onVisitorCenter(){
				uni.navigateTo({
					url:"../visitor/visitorCenter"
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
