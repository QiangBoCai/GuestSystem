<template>
	<view>
		我的预约申请：
		主要包括访客预约需要填报的详细信息：
		访客姓名，手机，证据类型，证据号码，访客单位，访客头像上传，访客车牌号，访客事由，访客留言，访客日期，结束日期，其他信息等。
		另外可以新增多名访客信息；
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
