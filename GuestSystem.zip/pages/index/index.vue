<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text> 
		</view>
		
		<navigator url="../visitor/visitorLogin" open-type="navigate">
			<button type="primary" hover-class="none">访客入口</button>
		</navigator>
		<navigator url="../employee/employeeLogin" open-type="navigate">
			<button type="primary" hover-class="none">员工入口</button>
		</navigator>
		<navigator url="../access/accessLogin"" open-type="navigate">
			<button type="primary" hover-class="none" >门禁入口</button>
		</navigator>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '欢迎使用OdmSz访客管理系统'
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
		border: 2px;
		color: black;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
	navigator{
		
			margin-top:30rpx;
	}
	button{
		width: 400rpx;
		height: 120rpx;
	}
</style>
