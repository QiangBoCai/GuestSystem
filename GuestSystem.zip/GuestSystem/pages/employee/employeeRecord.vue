<template>
	<view>
		授权记录：
		员工可以在授权记录页查看曾经发出的授权申请记录以及状态，根据已填报的记录进行授权，或者打回等审批状态；
		展示所有的授权记录；
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
