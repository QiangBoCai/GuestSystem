<template>
<<<<<<< HEAD
	<view class="box" >
			<view class="item" @click="onEmployeeOrder">
				<u--image class="icon" src="/static/order.png" width="50px" height="50px"></u--image>
				<text>授权申请</text>
			</view>
			<view class="item" @click="onEmployeeRecord">
				<u--image class="icon" src="/static/record.png" width="50px" height="50px"></u--image>
				<text>授权记录</text>
			</view>
			<view class="item" @click="onEmployeeCenter">
				<u--image class="icon" src="/static/person.png" width="50px" height="50px"></u--image>
				<text>个人中心</text>
			</view>
	
=======
	<view>
		<view @click="onEmployeeOrder">授权申请</view>
		<view @click="onEmployeeRecord">授权记录</view>
		<view @click="onEmployeeCenter">个人中心</view>
>>>>>>> a0f813343f2aed3918e9a4bd7797c5a81943739b
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onEmployeeOrder(){
				uni.navigateTo({
					url:"../employee/employeeOrder"
				})
			},
			onEmployeeRecord(){
				uni.navigateTo({
					url:"../employee/employeeRecord"
				})
			},
			onEmployeeCenter(){
				uni.navigateTo({
					url:"../employee/employeeCenter"
				})
			}
		}
	}
</script>

<style lang="scss">
.box{
		padding-top:50rpx;
		display: flex;
		justify-content: center; // 内容自适应：上下居中
		align-items: center; // 子项对齐方式：左右居中
		.item{
			padding-left:60rpx;
			width: 250rpx;
			font-size: 35rpx;
		}
	}
</style>
