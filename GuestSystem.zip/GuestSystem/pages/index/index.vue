<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text> 
		</view>
<<<<<<< HEAD
		<view class = "enter"> 
			<u-button class = "btn" type="success"  text="访客入口" @click="enterVisitor"></u-button>
		</view>
		<view class = "enter">
			<u-button  class = "btn"  type="success"  text="员工入口" @click="enterEmployee"></u-button>
		</view>
		<view class = "enter">
			<u-button  class = "btn" type="success"  text="门禁入口" @click="enterAccess" ></u-button>
		</view>
	
=======
		
		<navigator url="../visitor/visitorLogin" open-type="navigate">
			<button type="primary" hover-class="none">访客入口</button>
		</navigator>
		<navigator url="../employee/employeeLogin" open-type="navigate">
			<button type="primary" hover-class="none">员工入口</button>
		</navigator>
		<navigator url="../access/accessLogin"" open-type="navigate">
			<button type="primary" hover-class="none" >门禁入口</button>
		</navigator>
>>>>>>> a0f813343f2aed3918e9a4bd7797c5a81943739b
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '欢迎使用OdmSz访客管理系统'
			}
		},
		onLoad() {
		},
		methods: {
		//检查是否授权登录
			authLogin() {
				////弹窗授权
				//showModal用于触发uni.getUserProfile弹窗
				uni.showModal({
					title: '授权登录',
					content: '是否授权登录微信小程序？',
					success: () => {
						uni.getUserProfile({
							desc: '登录后可同步数据',
							lang: 'zh_CN',
							success: (infoRes) => {
								console.log('用户信息-----------', infoRes)
								//获取code
								uni.login({
									provider: 'weixin',
									success: (loginRes) => {
										console.log('获取code-----------', loginRes)
										//调用接口传递参数
										let parames = {
											code: loginRes.code,
											encryptedData: infoRes
												.encryptedData,
											iv: infoRes.iv,
											signature: infoRes.signature,
											rawData: infoRes.rawData
										};
										console.log('将参数传给后端-----------', parames)
										uni.request({url: '',data: {parames: parames,}}).then((res) => {
											//获取到 openid 和 session_k后，自己的逻辑
											if(res.code==1){
												console.log('授权登录成功', res.data);
												console.log(res.data.openid);
												console.log(res.data.session_key);
											}
										});
									},
									fail: function(err) {
										uni.showToast({
											icon: 'none',
											title: '授权失败'
										})
									}
								});
							},
							fail: function(err) {
								uni.showToast({
									icon: 'none',
								title: '授权失败'
								})
							}
						});
					}
				})
					
				//未弹窗授权
				// 获取用户信息， 传给后端换取openid / uuid
				uni.getUserInfo({
					provider: 'weixin',
					success: function(infoRes) {
						console.log('infoRes', infoRes)
						//获取code
						uni.login({
							provider: 'weixin',
							success: (loginRes) => {
								console.log('loginRes', loginRes);
								//调用接口传递参数
								let parames = {
									code: loginRes.code,
									encryptedData: infoRes.encryptedData,
									iv: infoRes.iv,
									signature: infoRes.signature,
									rawData: infoRes.rawData
								};
							},
							fail: function(err) {
								uni.showToast({
									icon: 'none',
									title: '授权失败，请重新授权'
								})
							}
						});
					},
					fail: function(err) {
						uni.showToast({
							icon: 'none',
							title: '授权失败，请重新授权'
						})
					}
				});
			},
	
			enterVisitor(){
				// authLogin()
				uni.navigateTo({
					url:"/pages/visitor/visitor"
				})
			},
			enterEmployee(){
				// authLogin()
				uni.navigateTo({
					url:"/pages/employee/employee"
				})
			},
			enterAccess(){
				// authLogin()
				uni.navigateTo({
					url:"/pages/access/access"
				})
			}
				
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
		border: 2px;
		color: black;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
	.enter{
		margin-top: 20px;
		width: 300rpx;
	}
	.btn{
		background-color: #84e29c;
	}
</style>
