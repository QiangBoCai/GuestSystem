<template>
<<<<<<< HEAD
	<view class="box" >
			<view class="item" @click="onVisitorOrder">
				<u--image class="icon" src="/static/order.png" width="50px" height="50px"></u--image>
				<text>访客预约</text>
			</view>
			<view class="item" @click="onVisitorRecord">
				<u--image class="icon" src="/static/record.png" width="50px" height="50px"></u--image>
				<text>我的记录</text>
			</view>
			<view class="item" @click="onVisitorCenter">
				<u--image class="icon" src="/static/person.png" width="50px" height="50px"></u--image>
				<text>个人中心</text>
			</view>
	
=======
	<view>
			<view @click="onVisitorOrder">访客预约</view>
			<view @click="onVisitorRecord">我的记录</view>
			<view @click="onVisitorCenter">个人中心</view>
>>>>>>> a0f813343f2aed3918e9a4bd7797c5a81943739b
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			onVisitorOrder(){
<<<<<<< HEAD
				
=======
>>>>>>> a0f813343f2aed3918e9a4bd7797c5a81943739b
				uni.navigateTo({
					url:"../visitor/visitorOrder"
				})
			},
			onVisitorRecord(){
				uni.navigateTo({
					url:"../visitor/visitorRecord"
				})
			},
			onVisitorCenter(){
				uni.navigateTo({
					url:"../visitor/visitorCenter"
				})
			}
		}
	}
</script>

<style lang="scss">
	.box{
		padding-top:50rpx;
		display: flex;
		justify-content: center; // 内容自适应：上下居中
		align-items: center; // 子项对齐方式：左右居中
		.item{
			padding-left:60rpx;
			width: 250rpx;
			font-size: 35rpx;
		}
	}
</style>
