<template>
	<view>
		我的记录：
		主要包含访客的访客记录及状态，填报访客申请提交后，后续可以在我的记录中查看申请是否被审核通过，展示过往的访客记录。
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
